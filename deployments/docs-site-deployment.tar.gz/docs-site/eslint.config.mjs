export default [
  {
    ignores: ['**/*'],
  },
];