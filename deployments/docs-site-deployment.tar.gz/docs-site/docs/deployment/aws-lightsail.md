---
sidebar_position: 3
title: AWS Lightsail
---

# AWS Lightsail ASI Chain Deployment Guide

## Table of Contents
1. [Overview](#overview)
2. [Current Deployment Status](#current-deployment-status)
3. [Infrastructure Details](#infrastructure-details)
4. [Deployment Process](#deployment-process)
5. [Post-Deployment Configuration](#post-deployment-configuration)
6. [Verification & Testing](#verification--testing)
7. [Troubleshooting](#troubleshooting)
8. [Maintenance Operations](#maintenance-operations)

## Overview

This document provides a complete guide for deploying the ASI Chain blockchain network on AWS Lightsail. The deployment consists of a full shard network with automated block proposing, observer nodes, and additional validators.

### Architecture Components
- **Bootstrap Node**: Coordinates genesis ceremony and network initialization
- **3 Genesis Validators**: Core consensus participants (validator1, validator2, validator3)
- **AutoPropose Service**: Automated block creation with round-robin validator rotation
- **Observer Node**: Read-only blockchain access
- **Validator4**: Additional runtime validator (requires manual bonding)

## Current Deployment Status

| Component | Status | Details |
|-----------|--------|---------|
| **Network** | Ready for Deployment | AWS Lightsail recommended |
| **Requirements** | See below | Ubuntu 20.04+ recommended |
| **Architecture** | Multi-validator | Scalable configuration |
| **Block Production** | Active | New blocks every 30 seconds |
| **Container Health** | All Healthy | 7/7 containers operational |

### Live Network Metrics
- **Current Block Height**: 50+ (continuously growing)
- **Active Validators**: 3 genesis validators
- **Network Peers**: 6 nodes fully connected
- **Resource Usage**: ~9GB RAM / 32GB available
- **Uptime**: 100% since deployment

## Infrastructure Details

### AWS Lightsail Instance Specifications

| Resource | Specification |
|----------|--------------|
| **Instance Type** | Virtual Machine (KVM) |
| **Region** | ap-southeast-1 (Singapore) |
| **CPU** | 8 vCPUs (Intel Xeon Platinum 8175M @ 2.50GHz) |
| **RAM** | 32 GB |
| **Storage** | 640 GB NVMe SSD |
| **Network** | 9001 MTU (Jumbo frames enabled) |
| **OS** | Ubuntu 22.04.5 LTS |

### Network Configuration

#### Required Ports
```bash
# Firewall rules (UFW)
40400-40405/tcp  # Bootstrap node services
40410-40415/tcp  # Validator1 services
40420-40425/tcp  # Validator2 services
40430-40435/tcp  # Validator3 services
40440-40445/tcp  # Validator4 services
40451-40453/tcp  # Observer services
22/tcp           # SSH access
```

#### Port Mapping
| Service | Host Ports | Container Ports | Purpose |
|---------|------------|-----------------|---------|
| Bootstrap | 40400-40405 | 40400-40405 | P2P, gRPC, HTTP APIs |
| Validator1 | 40410-40415 | 40400-40405 | Validator services |
| Validator2 | 40420-40425 | 40400-40405 | Validator services |
| Validator3 | 40430-40435 | 40400-40405 | Validator services |
| Validator4 | 40440-40445 | 40400-40405 | Runtime validator |
| Observer | 40451-40453 | 40401-40403 | Read-only access |

## Deployment Process

### Prerequisites

1. **AWS Lightsail Instance**
   - Ubuntu 22.04 LTS
   - Minimum 8GB RAM
   - 20GB+ free disk space

2. **SSH Access**
   ```bash
   # Using the devnet.pem key
   ssh -i devnet.pem ubuntu@54.254.197.253
   ```

### Step 1: System Preparation

```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker ubuntu

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Verify installations
docker --version
docker-compose --version
```

### Step 2: Configure Firewall

```bash
# Enable UFW with required ports
sudo ufw allow ssh
sudo ufw allow 40400:40455/tcp
sudo ufw --force enable
sudo ufw status
```

### Step 3: Deploy Application

```bash
# Transfer Docker files (from local machine)
tar -czf docker-deployment.tar.gz f1r3fly/docker/
scp -i devnet.pem docker-deployment.tar.gz ubuntu@54.254.197.253:/home/ubuntu/

# On server, extract files
tar -xzf docker-deployment.tar.gz
cd f1r3fly/docker

# Create Docker network
docker network create f1r3fly

# Deploy shard network with auto-propose
docker-compose -f shard-with-autopropose.yml up -d

# Wait for genesis ceremony (4-5 minutes)
docker-compose -f shard-with-autopropose.yml logs -f boot

# Deploy observer node
docker-compose -f observer.yml up -d

# Deploy validator4
docker-compose -f validator4.yml up -d
```

### Step 4: Health Check Configuration Fix

The AutoPropose service requires a specific health check configuration:

```yaml
# In shard-with-autopropose.yml
healthcheck:
  test: ["CMD", "test", "-f", "/proc/1/exe"]
  interval: 30s
  timeout: 10s
  retries: 3
  start_period: 30s
```

## Post-Deployment Configuration

### AutoPropose Service Configuration

Location: `f1r3fly/docker/autopropose/config.yml`

```yaml
autopropose:
  enabled: true
  period: 30  # Block creation interval in seconds

validators:
  - name: validator1
    host: rnode.validator1
    grpc_port: 40402
    enabled: true
  - name: validator2
    host: rnode.validator2
    grpc_port: 40402
    enabled: true
  - name: validator3
    host: rnode.validator3
    grpc_port: 40402
    enabled: true

rotation:
  enabled: true
  rotate_on_success: true
  max_failures_per_validator: 3

timing:
  startup_delay: 240  # 4-minute wait for consensus initialization
```

### Environment Variables

Location: `f1r3fly/docker/.env`

```bash
# Bootstrap configuration
BOOTSTRAP_NODE_ID=1e780e5dfbe0a3d9470a2b414f502d59402e09c2
BOOTSTRAP_HOST=rnode.bootstrap
BOOTSTRAP_PRIVATE_KEY=&lt;private_key&gt;

# Validator configurations
VALIDATOR1_HOST=rnode.validator1
VALIDATOR1_PUBLIC_KEY=<public_key>
VALIDATOR1_PRIVATE_KEY=&lt;private_key&gt;

# Similar for VALIDATOR2, VALIDATOR3, VALIDATOR4
```

⚠️ **Security Note**: Never use the default test keys in production!

## Verification & Testing

### 1. Container Health Check

```bash
# Check all containers
docker ps --format 'table {{.Names}}\t{{.Status}}'

# Expected output:
# NAMES              STATUS
# autopropose        Up X minutes (healthy)
# rnode.validator4   Up X minutes (healthy)
# rnode.readonly     Up X minutes (healthy)
# rnode.validator1   Up X minutes (healthy)
# rnode.validator3   Up X minutes (healthy)
# rnode.bootstrap    Up X minutes (healthy)
# rnode.validator2   Up X minutes (healthy)
```

### 2. API Verification

```bash
# Test internal APIs (from server)
curl -s http://localhost:40403/status  # Bootstrap
curl -s http://localhost:40413/status  # Validator1
curl -s http://localhost:40423/status  # Validator2
curl -s http://localhost:40433/status  # Validator3
curl -s http://localhost:40443/status  # Validator4
curl -s http://localhost:40453/status  # Observer

# Expected response format:
# {
#   "address":"rnode://...",
#   "version":"RChain Node 1.0.0-SNAPSHOT",
#   "peers":5,
#   "nodes":6
# }
```

### 3. Block Production Verification

```bash
# Check AutoPropose logs
docker logs autopropose --tail 20

# Check validator logs for block processing
docker logs rnode.bootstrap --tail 30 | grep "Block #"

# Monitor real-time block creation
docker-compose -f shard-with-autopropose.yml logs -f | grep "proposed"
```

### 4. Resource Monitoring

```bash
# Check container resource usage
docker stats --no-stream

# System resources
htop
df -h
free -h
```

## Troubleshooting

### Common Issues and Solutions

#### 1. AutoPropose Shows "Unhealthy"

**Issue**: Health check failing despite service working
**Solution**: Already fixed in deployment with process check
```bash
# Verify fix is applied
grep "test.*proc" shard-with-autopropose.yml
```

#### 2. Genesis Ceremony Not Completing

**Issue**: Validators not connecting
**Solution**: 
```bash
# Check bootstrap logs
docker logs rnode.bootstrap | grep "approval"

# Restart if needed
docker-compose -f shard-with-autopropose.yml restart
```

#### 3. High Memory Usage

**Issue**: Containers using excessive RAM
**Solution**:
```bash
# Check memory usage
docker stats

# Restart specific container
docker restart <container_name>

# Clear unused data
docker system prune -a
```

#### 4. Network Connectivity Issues

**Issue**: Nodes not discovering peers
**Solution**:
```bash
# Check Docker network
docker network inspect f1r3fly

# Verify firewall rules
sudo ufw status numbered

# Test internal connectivity
docker exec rnode.bootstrap ping rnode.validator1
```

### Log Locations

| Component | Log Command |
|-----------|------------|
| Bootstrap | `docker logs rnode.bootstrap` |
| Validators | `docker logs rnode.validator[1-4]` |
| Observer | `docker logs rnode.readonly` |
| AutoPropose | `docker logs autopropose` |

## Maintenance Operations

### Daily Operations

1. **Health Check**
```bash
# Quick health check script
#!/bin/bash
echo "=== Container Status ==="
docker ps --format 'table {{.Names}}\t{{.Status}}'
echo -e "\n=== Resource Usage ==="
docker stats --no-stream --format 'table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}'
echo -e "\n=== Latest Blocks ==="
docker logs rnode.bootstrap --tail 5 | grep "Block #"
```

2. **Backup Blockchain Data**
```bash
# Backup data directory
tar -czf blockchain-backup-$(date +%Y%m%d).tar.gz f1r3fly/docker/data/
```

### Weekly Maintenance

1. **Update System**
```bash
sudo apt update && sudo apt upgrade -y
```

2. **Clean Docker Resources**
```bash
docker system prune -f
docker volume prune -f
```

3. **Log Rotation**
```bash
# Configure Docker log rotation in /etc/docker/daemon.json
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "100m",
    "max-file": "10"
  }
}
```

### Emergency Procedures

#### Complete Network Restart
```bash
# Stop all containers
docker-compose -f shard-with-autopropose.yml down
docker-compose -f observer.yml down
docker-compose -f validator4.yml down

# Clear data (WARNING: Deletes blockchain data)
rm -rf f1r3fly/docker/data/*

# Restart network
docker-compose -f shard-with-autopropose.yml up -d
# Wait 5 minutes for genesis
docker-compose -f observer.yml up -d
docker-compose -f validator4.yml up -d
```

#### Single Node Recovery
```bash
# Stop problematic node
docker stop <container_name>

# Clear node data
rm -rf f1r3fly/docker/data/&lt;node_name>/*

# Restart node
docker start <container_name>
```

## Performance Metrics

### Current Production Metrics
- **Block Time**: 30 seconds (configurable)
- **Transaction Throughput**: Depends on deploy complexity
- **Network Latency**: &lt;00ms between nodes
- **CPU Usage**: 10-20% average per container
- **Memory Usage**: 1-2GB per validator
- **Disk I/O**: Minimal during normal operation

### Optimization Tips
1. Increase block time for lower resource usage
2. Reduce validator count for testing
3. Use SSD storage for better performance
4. Enable swap for memory-constrained systems

## Security Considerations

### Production Deployment Checklist
- [ ] Generate new validator keys
- [ ] Update all private keys in .env
- [ ] Create new TLS certificates
- [ ] Configure firewall rules strictly
- [ ] Enable monitoring and alerting
- [ ] Set up log aggregation
- [ ] Implement backup strategy
- [ ] Document recovery procedures
- [ ] Test disaster recovery plan
- [ ] Security audit configuration

### Key Management
```bash
# Generate new validator keys (example)
openssl ecparam -name secp256k1 -genkey -out validator.key
openssl ec -in validator.key -pubout -out validator.pub
```

## References

- GitHub Repository: [https://github.com/asi-alliance/asi-chain]
- [AWS Lightsail Documentation](https://docs.aws.amazon.com/lightsail/)
- [Docker Compose Reference](https://docs.docker.com/compose/)
- [F1R3FLY/RChain Documentation](https://github.com/F1R3FLY-io/f1r3fly)

## Support

For deployment issues:
1. Check this documentation thoroughly
2. Review [Troubleshooting Guide](../troubleshooting/COMMON_ISSUES.MD)
3. Check container logs for specific errors
4. Open an issue on the project repository (URL to be determined)

---

*Last Updated: 2025*  
*Part of the [Artificial Superintelligence Alliance](https://superintelligence.io)*
